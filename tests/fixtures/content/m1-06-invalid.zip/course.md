---
schema: course/v1.1
id: euler-olympiad
title: Подготовка к олимпиаде Эйлера
---

Курс по олимпиадной математике. Формула Эйлера: $V-E+F=2$. ![Схема](./assets/student/images/euler.png)
