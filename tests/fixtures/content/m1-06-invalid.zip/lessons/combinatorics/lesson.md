---
schema: lesson/v1.1
id: combinatorics
title: Комбинаторные конструкции
order: 2
---

Теория занятия 2: $a \equiv b \pmod m$.
