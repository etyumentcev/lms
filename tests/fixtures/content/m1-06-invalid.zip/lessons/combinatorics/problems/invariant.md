---
schema: problem/v1.1
id: invariant
title: Инвариант раскраски
order: 1
source: Synthetic M1-06
---

Найдите инвариант и обоснуйте невозможность конфигурации.
