---
schema: problem/v1.1
title: Задача 1
order: 1
source: Synthetic M1-06
---

Докажите утверждение для $n=1$ и вычислите остаток по модулю $3$.
