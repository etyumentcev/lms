---
schema: problem/v1.1
id: congruence-2
title: Задача 2
order: 2
source: Synthetic M1-06
---

Докажите утверждение для $n=2$ и вычислите остаток по модулю $4$.
