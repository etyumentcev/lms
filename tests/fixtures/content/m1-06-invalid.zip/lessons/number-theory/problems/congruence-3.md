---
schema: problem/v1.1
id: congruence-3
title: Задача 3
order: 3
source: Synthetic M1-06
---

Докажите утверждение для $n=3$ и вычислите остаток по модулю $5$.
