---
schema: problem/v1.1
id: congruence-4
title: Задача 4
order: 4
source: Synthetic M1-06
---

Докажите утверждение для $n=4$ и вычислите остаток по модулю $6$.
