---
schema: problem/v1.1
id: congruence-5
title: Задача 5
order: 5
source: Synthetic M1-06
---

Докажите утверждение для $n=5$ и вычислите остаток по модулю $7$.
