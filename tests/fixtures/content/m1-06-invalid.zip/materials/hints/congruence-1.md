---
schema: hints/v1
id: hint-congruence-1
targetKind: problem
targetId: congruence-1
order: 1
publication: with-problem
---

Рассмотрите классы вычетов и небольшой пример.
