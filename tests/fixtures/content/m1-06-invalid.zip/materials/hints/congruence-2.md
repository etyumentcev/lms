---
schema: hints/v1
id: hint-congruence-2
targetKind: problem
targetId: congruence-2
order: 1
publication: with-problem
---

Рассмотрите классы вычетов и небольшой пример.
