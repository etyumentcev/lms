---
schema: hints/v1
id: hint-congruence-3
targetKind: problem
targetId: congruence-3
order: 1
publication: with-problem
---

Рассмотрите классы вычетов и небольшой пример.
