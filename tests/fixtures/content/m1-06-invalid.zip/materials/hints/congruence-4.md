---
schema: hints/v1
id: hint-congruence-4
targetKind: problem
targetId: congruence-4
order: 1
publication: with-problem
---

Рассмотрите классы вычетов и небольшой пример.
