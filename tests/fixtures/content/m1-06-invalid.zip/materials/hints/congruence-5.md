---
schema: hints/v1
id: hint-congruence-5
targetKind: problem
targetId: congruence-5
order: 1
publication: with-problem
---

Рассмотрите классы вычетов и небольшой пример.
