---
schema: hints/v1
id: hint-invariant
targetKind: problem
targetId: invariant
order: 1
publication: withheld
---

M1_TEACHER_ONLY_HINT: исследуйте чётность.
