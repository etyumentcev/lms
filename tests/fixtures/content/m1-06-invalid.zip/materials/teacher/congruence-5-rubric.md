---
schema: teacher/v1
id: rubric-congruence-5
targetKind: problem
targetId: congruence-5
kind: rubric
order: 2
---

M1_TEACHER_ONLY_RUBRIC: проверены идея, выкладки и ответ.
