---
schema: teacher/v1
id: solution-congruence-5
targetKind: problem
targetId: congruence-5
kind: solution
order: 1
---

M1_TEACHER_ONLY_SOLUTION_v1: полное решение задачи 5.
