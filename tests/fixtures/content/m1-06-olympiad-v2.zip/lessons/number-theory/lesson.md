---
schema: lesson/v1.1
id: number-theory
title: Остатки и сравнения
order: 1
---

Теория занятия 1: $a \equiv b \pmod m$.

![Схема сравнения](../../assets/student/images/euler.png)
