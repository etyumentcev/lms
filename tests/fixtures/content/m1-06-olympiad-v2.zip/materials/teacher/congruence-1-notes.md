---
schema: teacher/v1
id: notes-congruence-1
targetKind: problem
targetId: congruence-1
kind: notes
order: 3
---

M1_TEACHER_ONLY_NOTES: обсудите альтернативный ход после самостоятельной попытки.
