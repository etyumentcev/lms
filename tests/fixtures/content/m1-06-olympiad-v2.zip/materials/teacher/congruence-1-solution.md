---
schema: teacher/v1
id: solution-congruence-1
targetKind: problem
targetId: congruence-1
kind: solution
order: 1
---

M1_TEACHER_ONLY_SOLUTION_v2: полное решение задачи 1.
