---
schema: teacher/v1
id: solution-congruence-3
targetKind: problem
targetId: congruence-3
kind: solution
order: 1
---

M1_TEACHER_ONLY_SOLUTION_v2: полное решение задачи 3.
